<?php 
require ('config.inc.php'); 
$page_title = 'Logout Page';

//1 - include the header file

//2 - 

//3 - include the header file

?>